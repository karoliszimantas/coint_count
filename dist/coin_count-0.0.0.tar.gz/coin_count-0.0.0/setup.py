import setuptools

setuptools.setup(
    name="coin_count",
    description="Application prints a change to be returned from a given sum amount in the number of coins")
